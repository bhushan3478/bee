

function getAllData() {
  //alert("Hello")
  var reruest = new XMLHttpRequest();
        var Report = new XMLHttpRequest();
        var Transection = new XMLHttpRequest();

        reruest.open('get', 'http://54.88.119.46:4231/bee/v1/bike/getBikesData');
        Report.open('get', 'http://54.88.119.46:4231/bee/v1/report/getBikeReport');

        Transection.open('get', 'http://54.88.119.46:4231/bee/v1/transaction/getTransactions');


        reruest.onload = function() {

            var data = JSON.parse(reruest.responseText);
            var Transdata = JSON.parse(Transection.responseText);
            // mydata(data);
            DailyTransection(Transdata)


        };
        reruest.send();
        Transection.send();
}

if(btn){
    btn.addEventListener("click", function() {

        
    });
}

function DailyTransection(tdata) {
    console.log(tdata)
    var str2 = "";
    var a = [];
    var b = [];
    var d;
    var c, count = 0;

    for (i = 0; i < tdata.length; i++) {
        c = tdata.length;
        a.push("<div border=1>" + "Transection Id:" + tdata[i].transactionId + "</div>");

        if (tdata[i].paymentStatus === "Unpaid") {
            //  b.push("<ul><h5>" + "<li>" + "TRNS ID:" + tdata[i].transactionId + "&nbsp;USER ID:" + tdata[i].userId + "&nbsp;STATUS:" + tdata[i].paymentStatus + "</li>" + "</h5></ul>");
            count++;
        }

    }

    document.getElementById("unpaidUsers").innerHTML = count;
    //demo.insertAdjacentHTML('afterend', c);
    //demo2.insertAdjacentHTML('afterend', count);
   
};


/*
            //var btn2 = document.getElementById("btn2");
            var demo2 = document.getElementById('demo2');
            var demo3 = document.getElementById('demo3');

            btn.addEventListener("click", function() {

                var reruest = new XMLHttpRequest();
                var Report = new XMLHttpRequest();
                var Transection = new XMLHttpRequest();

                reruest.open('get', 'http://54.88.119.46:4231/bee/v1/bike/getBikesData');
                Report.open('get', 'http://54.88.119.46:4231/bee/v1/report/getBikeReport');

                Transection.open('get', 'http://54.88.119.46:4231/bee/v1/transaction/getTransactions');


                reruest.onload = function() {

                    var data = JSON.parse(reruest.responseText);
                    var Transdata = JSON.parse(Transection.responseText);
                    // mydata(data);
                    DailyTransection(Transdata)


                };
                reruest.send();
                Transection.send();


            });


            function mydata(sampleData) {
                var str = "";

                var str3 = ""
                var b, c;

                 str += "<table><tr> <th>IMEI</th>" +

                     "<th>DECIVE ID</th>" +
                     "<th>LATTITDUE</th>" +
                     "<th>LONGITUDE</th>" +
                     "<th>IGNITION STATUS</th>" +
                     "<th>LAST IGNITION ON TIME</th>" +
                     "<th>LAST IGNITION OFF TIME</th>" +
                     "<th>SPEED</th>" +
                     "<th>TIME</th>" +
                     "<th>SPEED</th>" +
                     "<th>SERVER TIME STAMP</th>" +
                     "<th>LAST POWER CUT TIME</th>" +
                     "<th>LAST SOS TIME</th>" +
                     "<th>LAST NO GPS SIGNAL</th>" +
                     "<th>LAST REMAINIG KM</th>" +
                     "<th>BIKE ID</th>" +
                     "</tr>";
                     
                for (i = 0; i < sampleData.length; i++) {


                    if (sampleData[i].remainingKm * 2 == 20) {
                        a = sampleData[i].remainingKm * 2;
                        str += "<h2>" + sampleData[i].remainingKm + "Km Remaining" + "&nbsp;&nbsp;" + "bike id:" + sampleData[i].bikeId + "&nbsp;Remaining Battry is&nbsp;" + a + "%</h2>";

                    }
                    //  str += "</table>";
                    demo.insertAdjacentHTML('beforeend', str);

                }
            };

            function DailyTransection(tdata) {
                var str2 = "";
                var a = [];
                var b = [];
                var d;
                var c, count = 0;

                for (i = 0; i < tdata.length; i++) {
                    c = tdata.length;
                    a.push("<div border=1>" + "Transection Id:" + tdata[i].transactionId + "</div>");

                    if (tdata[i].paymentStatus === "Unpaid") {
                        //  b.push("<ul><h5>" + "<li>" + "TRNS ID:" + tdata[i].transactionId + "&nbsp;USER ID:" + tdata[i].userId + "&nbsp;STATUS:" + tdata[i].paymentStatus + "</li>" + "</h5></ul>");
                        count++;
                    }

                }
                demo.insertAdjacentHTML('afterend', "<h2>" + c + "</h2>");
                demo2.insertAdjacentHTML('afterend', count);
                // demo3.insertAdjacentHTML('afterend', "<h2>" + c + "</h2>");

            };
        */